from seshat.transformer import Transformer


class Reducer(Transformer):
    def reduce(self):
        pass
