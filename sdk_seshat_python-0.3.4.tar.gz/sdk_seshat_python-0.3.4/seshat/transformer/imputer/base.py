from seshat.transformer import Transformer


class Imputer(Transformer):
    def impute(self):
        pass
