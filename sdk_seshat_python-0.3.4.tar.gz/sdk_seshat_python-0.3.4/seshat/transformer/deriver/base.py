from typing import Dict, Callable, List

import pandas as pd
from pandas import DataFrame
from pyspark.sql import DataFrame as PySparkDataFrame
from pyspark.sql import functions as F
from pyspark.sql.functions import array_distinct, array_union, coalesce, array
from pyspark.sql.types import IntegerType, StructType, StructField

from seshat.data_class import SFrame, SPFrame
from seshat.data_class.base import GroupSFrame
from seshat.data_class.pandas import DFrame
from seshat.general import configs
from seshat.transformer import Transformer
from seshat.utils import pandas_func
from seshat.utils import pyspark_func
from seshat.utils.validation import ensure_is_numeric

SYMBOLS_RECEIVED_COL = "symbols_received"
SYMBOLS_SENT_COL = "symbols_sent"


class SFrameDeriver(Transformer):
    """
    Interface for deriver, specially set handler name to `derive` for all other derivers.
    """

    ONLY_GROUP = False
    HANDLER_NAME = "derive"
    DEFAULT_FRAME = DFrame


class SFrameFromColsDeriver(SFrameDeriver):
    """
    This class is used to create new sframe from specific columns of default sframes.
    If input is contained only one sframe the result is group sframe with two children.

    Parameters
    ----------
    cols : list of str
        List of columns in the default sframe to transformation must apply of them.
    result_col : str
        Column name of result values in address sframe
    """

    ONLY_GROUP = False
    DEFAULT_GROUP_KEYS = {
        "default": configs.DEFAULT_SF_KEY,
        "address": configs.ADDRESS_SF_KEY,
    }

    def __init__(
        self,
        group_keys=None,
        cols=(configs.FROM_ADDRESS_COL, configs.TO_ADDRESS_COL),
        result_col="extracted_value",
    ):
        super().__init__(group_keys)
        self.cols = cols
        self.result_col = result_col

    def validate(self, sf: SFrame):
        super().validate(sf)
        self._validate_columns(sf, self.default_sf_key, *self.cols)

    def derive_df(self, default: DataFrame, *args, **kwargs) -> Dict[str, DataFrame]:
        new_df = DataFrame()

        new_df[self.result_col] = pd.unique(default[[*self.cols]].values.ravel())
        new_df[self.result_col] = new_df[self.result_col].astype(
            default[self.cols[0]].dtype
        )
        new_df.dropna(subset=[self.result_col], inplace=True)
        return {"default": default, "address": new_df}

    def derive_spf(
        self, default: PySparkDataFrame, *args, **kwargs
    ) -> Dict[str, PySparkDataFrame]:
        temp_spf = default.withColumn(
            self.result_col, F.explode(F.array(*[F.col(c) for c in self.cols]))
        )
        address = temp_spf.select(self.result_col).distinct()
        return {"default": default, "address": address}


class FeatureForAddressDeriver(SFrameDeriver):
    """
    This class is responsible for adding a new column as a new feature to address the sframe
    based on the default sframe.

    Parameters
    ----------
    default_index_col : str
        Columns that group by default will be applied based on this column.
    address_index_col: str
        Column in the address that must be matched to address_col in default sframe.
        Joining default and address sframe using this column and address_col to
        join new column to address.
    result_col : str
        Column name for a new column in address sframe
    agg_func: str
        Function name that aggregation operates based on it. For example count, sum, mean, etc.
    """

    ONLY_GROUP = True
    DEFAULT_GROUP_KEYS = {
        "default": configs.DEFAULT_SF_KEY,
        "address": configs.ADDRESS_SF_KEY,
    }

    def __init__(
        self,
        value_col,
        group_keys=None,
        default_index_col: str | List[str] = configs.FROM_ADDRESS_COL,
        address_index_col: str | List[str] = configs.ADDRESS_COL,
        result_col="result_col",
        agg_func="mean",
        is_numeric=True,
    ):
        super().__init__(group_keys)

        self.value_col = value_col
        self.default_index_col = default_index_col
        self.address_index_col = address_index_col
        self.result_col = result_col
        self.agg_func = agg_func
        self.is_numeric = is_numeric

    def validate(self, sf: SFrame):
        super().validate(sf)
        self._validate_columns(sf, self.group_keys["default"], self.value_col)
        if isinstance(self.address_index_col, list):
            self._validate_columns(
                sf, self.group_keys["address"], *self.address_index_col
            )
        else:
            self._validate_columns(
                sf, self.group_keys["address"], self.address_index_col
            )

    def derive_df(
        self, default: DataFrame, address: DataFrame, *args, **kwargs
    ) -> Dict[str, DataFrame]:
        if self.is_numeric:
            ensure_is_numeric(default, self.value_col)

        zero_value = pandas_func.get_zero_value(default[self.value_col])
        default.fillna({self.value_col: zero_value}, inplace=True)

        df_agg = (
            default.groupby(self.default_index_col)[self.value_col]
            .agg(self.agg_func)
            .reset_index(name=self.result_col)
        )

        if isinstance(self.default_index_col, str):
            should_dropped = [self.default_index_col]
        else:
            should_dropped = set(self.default_index_col) - set(self.address_index_col)

        address = address.merge(
            df_agg,
            right_on=self.default_index_col,
            left_on=self.address_index_col,
            how="left",
        ).drop(should_dropped, axis=1)

        result_zero_value = pandas_func.get_zero_value(address[self.result_col])
        address.fillna({self.result_col: result_zero_value}, inplace=True)
        return {"default": default, "address": address}

    def derive_spf(
        self, default: PySparkDataFrame, address: PySparkDataFrame, *args, **kwargs
    ) -> Dict[str, PySparkDataFrame]:
        try:
            func = getattr(F, self.agg_func)
        except AttributeError:
            raise AttributeError(
                "agg func %s not available for pyspark dataframe" % self.agg_func
            )
        if self.is_numeric:
            default = ensure_is_numeric(default, self.value_col)

        zero_value = pyspark_func.get_zero_value(default, self.value_col)
        default = default.fillna({self.value_col: zero_value})

        agg_value = (
            default.groupBy(self.default_index_col)
            .agg(func(F.col(self.value_col)).alias(self.result_col))
            .withColumnRenamed(self.default_index_col, self.address_index_col)
        )
        address = address.join(agg_value, on=self.address_index_col, how="left")
        zero_value = pyspark_func.get_zero_value(address, self.result_col)
        address = address.fillna(zero_value, subset=[self.result_col])

        return {"default": default, "address": address}


class OperationOnColsDeriver(SFrameDeriver):
    """
    This deriver does some operation on two different columns of default sframe


    Parameters
    ----------
    cols: list of str
        List of column names that operation must be applied on them
    result_col: str
        Column name of result column
    agg_func: str
        Aggregation function name that operates on specified columns.

    """

    ONLY_GROUP = False
    DEFAULT_GROUP_KEYS = {"default": configs.DEFAULT_SF_KEY}

    def __init__(
        self,
        group_keys=None,
        cols=(configs.AMOUNT_COL,),
        result_col="interacted_value",
        agg_func: str | Callable = "mean",
        is_numeric=False,
    ):
        super().__init__(group_keys)
        self.cols = cols
        self.result_col = result_col
        self.agg_func = agg_func
        self.is_numeric = is_numeric

    def validate(self, sf: SFrame):
        super().validate(sf)
        self._validate_columns(sf, self.default_sf_key, *self.cols)

    def derive_df(self, default: DataFrame, *args, **kwargs):
        if self.is_numeric:
            for col in self.cols:
                default = ensure_is_numeric(default, col)
        default[self.result_col] = default[[col for col in self.cols]].agg(
            self.agg_func, axis=1
        )
        return {"default": default}

    def derive_spf(self, default: PySparkDataFrame, *args, **kwargs):
        if self.is_numeric:
            for col in self.cols:
                default = ensure_is_numeric(default, col)
        try:
            func = pyspark_func.func_maps[self.agg_func]
        except KeyError:
            raise KeyError(
                "func %s not available for pyspark dataframe" % self.agg_func
            )
        func_udf = F.udf(func)
        default = default.withColumn(self.result_col, func_udf(*self.cols))
        default = ensure_is_numeric(default, self.result_col)
        return {"default": default}


class PercentileTransactionValueDeriver(SFrameDeriver):
    """
    Used to compute percentile of the specific column and insert result as a new column.

    Parameters
    ----------
    value_col: str
        The column that computing percentile will execute on it.
    quantile_probabilities: list of float
        List of quantile probabilities
    result_col: str
        Column name of result column
    """

    def __init__(
        self,
        group_keys=None,
        value_col=configs.AMOUNT_COL,
        result_col="percentile",
        quantile_probabilities=(0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9),
    ):
        super().__init__(group_keys)

        self.value_col = value_col
        self.result_col = result_col
        self.quantile_probabilities = quantile_probabilities

    def validate(self, sf: SFrame):
        super().validate(sf)
        self._validate_columns(sf, self.default_sf_key, self.value_col)

    def derive_df(self, default: DataFrame, *args, **kwargs) -> Dict[str, DataFrame]:
        ensure_is_numeric(default, self.value_col)

        quantiles = default[self.value_col].quantile(
            self.quantile_probabilities, interpolation="linear"
        )
        percentile = pandas_func.PandasPercentile(quantiles)
        default[self.result_col] = default[self.value_col].apply(percentile)
        return {"default": default}

    def derive_spf(
        self, default: PySparkDataFrame, *args, **kwargs
    ) -> Dict[str, PySparkDataFrame]:
        quantiles = default.approxQuantile(
            self.value_col, self.quantile_probabilities, 0.05
        )

        def get_percentile(value):
            for i, quantile in enumerate(quantiles):
                if value <= quantile:
                    return (i + 1) * 10

            return 100

        get_percentile_udf = F.udf(get_percentile, IntegerType())
        default = default.withColumn(
            self.result_col, get_percentile_udf(F.col(self.value_col))
        )
        return {"default": default}


class InteractedSymbolsToSentenceDeriver(SFrameDeriver):
    """
    This deriver joins symbols that each user in address sframe
    be interacted with it into a new column in string type.
    If already sent symbols or received symbols are calculated as an array of symbol strings
    deriver use them otherwise compute these columns.

    Parameters
    ----------
    symbol_col: str
        Column name of a symbol column in default sframe
    from_address_col: str
        Column name of from address column in default sframe
    to_address_col: str
        Column name of to address column in default sframe
    address_address_col: str
        Column name of address column in address sframe. This column
        consider as a joining condition between default and address sframe
    sent_symbols_col : str
        Column name for the result of sent symbols column in address sframe. If this parameter is set to None
        sent symbols are computed and this value as a new column name.
    received_symbols_col : str
        Column name for the result of received symbols column in address sframe. If this parameter is set to None
        received symbols are computed and this value is a new column name.
    total_symbols_col : str
        Column name for merged two columns sent_symbols and received_symbols.
    result_col: str
        Column name of interacted symbols column
    """

    DEFAULT_GROUP_KEYS = {
        "default": configs.DEFAULT_SF_KEY,
        "address": configs.ADDRESS_SF_KEY,
    }

    def __init__(
        self,
        group_keys=None,
        symbol_col=configs.SYMBOL_COL,
        from_address_col=configs.FROM_ADDRESS_COL,
        to_address_col=configs.TO_ADDRESS_COL,
        address_address_col=configs.ADDRESS_COL,
        sent_symbols_col=None,
        received_symbols_col=None,
        total_symbols_col=None,
        result_col=None,
    ):
        super().__init__(group_keys)

        self.symbol_col = symbol_col
        self.from_address_col = from_address_col
        self.to_address_col = to_address_col
        self.address_address_col = address_address_col
        self.sent_symbols_col = sent_symbols_col
        self.received_symbols_col = received_symbols_col
        self.total_symbols_col = total_symbols_col
        self.result_col = result_col

    def validate(self, sf: SFrame):
        super().validate(sf)
        if self.sent_symbols_col is None:
            self._validate_columns(sf, self.default_sf_key, self.from_address_col)
        if self.received_symbols_col is None:
            self._validate_columns(sf, self.default_sf_key, self.to_address_col)

    def derive_df(
        self, address: DataFrame, default: DataFrame = None, *args, **kwargs
    ) -> Dict[str, DataFrame]:
        if self.sent_symbols_col is None:
            group_sf = GroupSFrame(
                children={
                    "default": DFrame.from_raw(default),
                    "address": DFrame.from_raw(address),
                }
            )

            address = (
                FeatureForAddressDeriver(
                    self.symbol_col,
                    self.group_keys,
                    self.from_address_col,
                    self.address_address_col,
                    SYMBOLS_SENT_COL,
                    "unique",
                    is_numeric=False,
                )(group_sf)
                .get(self.group_keys["address"])
                .to_raw()
            )

        if self.received_symbols_col is None:
            group_sf = GroupSFrame(
                children={
                    "default": DFrame.from_raw(default),
                    "address": DFrame.from_raw(address),
                }
            )
            address = (
                FeatureForAddressDeriver(
                    self.symbol_col,
                    self.group_keys,
                    self.to_address_col,
                    self.address_address_col,
                    SYMBOLS_RECEIVED_COL,
                    "unique",
                    is_numeric=False,
                )(group_sf)
                .get(self.group_keys["address"])
                .to_raw()
            )

        final_sent_col = self.sent_symbols_col or SYMBOLS_SENT_COL
        final_received_col = self.received_symbols_col or SYMBOLS_RECEIVED_COL

        address[final_sent_col] = address[final_sent_col].fillna("").apply(list)
        address[final_received_col] = address[final_received_col].fillna("").apply(list)

        address[self.result_col] = address.apply(
            lambda row: ", ".join(set(row[final_sent_col] + row[final_received_col])),
            axis=1,
        )
        return {"default": default, "address": address}

    def derive_spf(
        self,
        address: PySparkDataFrame,
        default: PySparkDataFrame = None,
        *args,
        **kwargs
    ) -> Dict[str, PySparkDataFrame]:
        if self.sent_symbols_col is None:
            group_sframe = GroupSFrame(
                children={
                    "default": SPFrame.from_raw(default),
                    "address": SPFrame.from_raw(address),
                }
            )

            address = (
                FeatureForAddressDeriver(
                    self.symbol_col,
                    self.group_keys,
                    self.from_address_col,
                    self.address_address_col,
                    SYMBOLS_SENT_COL,
                    "collect_set",
                    is_numeric=False,
                )(group_sframe)
                .get(self.group_keys["address"])
                .to_raw()
            )

        if self.received_symbols_col is None:
            group_sframe = GroupSFrame(
                children={
                    "default": SPFrame.from_raw(default),
                    "address": SPFrame.from_raw(address),
                }
            )
            address = (
                FeatureForAddressDeriver(
                    self.symbol_col,
                    self.group_keys,
                    self.to_address_col,
                    self.address_address_col,
                    SYMBOLS_RECEIVED_COL,
                    "collect_set",
                    is_numeric=False,
                )(group_sframe)
                .get(self.group_keys["address"])
                .to_raw()
            )
        final_sent_col = self.sent_symbols_col or SYMBOLS_SENT_COL
        final_received_col = self.received_symbols_col or SYMBOLS_RECEIVED_COL

        address = address.withColumn(
            final_sent_col, coalesce(final_received_col, array())
        )

        address = address.withColumn(
            self.result_col,
            F.concat_ws(
                ", ",
                array_distinct(array_union(final_received_col, final_sent_col)),
            ),
        )

        return {"default": default, "address": address}


class SenderReceiverTokensDeriver(SFrameDeriver):
    """
    This will find tokens that in at least one record be from_address or to_address.
    The result will save in another sf.
    """

    DEFAULT_GROUP_KEYS = {"default": "default", "other": configs.OTHER_SF_KEY}

    def __init__(
        self,
        group_keys=None,
        address_cols=(configs.FROM_ADDRESS_COL, configs.TO_ADDRESS_COL),
        contract_address_col=configs.CONTRACT_ADDRESS_COL,
        result_col=configs.CONTRACT_ADDRESS_COL,
        *args,
        **kwargs
    ):
        super().__init__(group_keys, *args, **kwargs)
        self.address_cols = address_cols
        self.contract_address = contract_address_col
        self.result_col = result_col

    def derive_df(self, default: DataFrame, *args, **kwargs):
        all_tokens = set(default[self.contract_address].tolist())
        addresses = set()
        for address_col in self.address_cols:
            addresses |= set(default[address_col].tolist())

        sender_receiver_tokens = list(addresses & all_tokens)
        other = pd.DataFrame(data={self.result_col: sender_receiver_tokens})
        return {"default": default, "other": other}

    def derive_spf(self, default: PySparkDataFrame, *args, **kwargs):
        all_tokens = set(
            default.select(self.contract_address).rdd.flatMap(lambda x: x).collect()
        )
        addresses = set()
        for address_col in self.address_cols:
            addresses |= set(
                default.select(address_col).rdd.flatMap(lambda x: x).collect()
            )

        sender_receiver_tokens = list(addresses & all_tokens)
        schema = StructType(
            [
                StructField(
                    self.result_col, default.schema[self.contract_address].dataType
                )
            ]
        )

        data = [{self.result_col: addr} for addr in sender_receiver_tokens]
        other = SPFrame.get_spark().createDataFrame(schema=schema, data=data)
        return {"default": default, "other": other}
