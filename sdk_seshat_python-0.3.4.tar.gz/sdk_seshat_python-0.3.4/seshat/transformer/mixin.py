from seshat.data_class import SFrame


class HandlerDispatcherMixin:
    HANDLER_NAME: str = "handle"

    def call_handler(self, sf: SFrame, *args, **kwargs):
        handler = getattr(self, f"{self.HANDLER_NAME}_{sf.frame_name}")
        return handler(*args, **kwargs)

    def should_convert(self, sf: SFrame):
        return not hasattr(self, f"{self.HANDLER_NAME}_{sf.frame_name}")
