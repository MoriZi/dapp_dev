from seshat.transformer import Transformer


class Augmenter(Transformer):
    def augment(self):
        pass
