from seshat.transformer import Transformer


class Scaler(Transformer):
    def scale(self):
        pass
