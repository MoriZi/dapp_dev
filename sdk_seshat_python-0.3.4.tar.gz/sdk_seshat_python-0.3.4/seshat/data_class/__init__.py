from .base import SFrame, GroupSFrame
from .pandas import DFrame
from .pyspark import SPFrame

SF_MAP = {DFrame.frame_name: DFrame, SPFrame.frame_name: SPFrame}
