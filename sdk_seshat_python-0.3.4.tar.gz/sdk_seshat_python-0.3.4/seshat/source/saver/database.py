import hashlib
import statistics
from typing import List

import sqlalchemy as db
from sqlalchemy import Column, inspect
from sqlalchemy import Index
from sqlalchemy import Table, MetaData, select, update, and_, true

from seshat.data_class import SFrame
from seshat.general.exceptions import InvalidArgumentsError
from seshat.source.mixins import SQLMixin
from seshat.source.saver import Saver
from seshat.source.saver.base import SaveConfig
from seshat.transformer.schema import Schema
from seshat.transformer.schema.base import UpdateFuncs


class SQLDBSaver(SQLMixin, Saver):
    def __init__(self, url, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.url = url

    def save(self, sf: SFrame, *args, **kwargs):
        for config in self.save_configs:
            self.fill_cols_to_field(config.schema)
            self.ensure_table_exists(config.table, config.schema)
            self.create_index(config)
            selected_sf = sf.get(config.sf_key)
            if config.strategy == "update":
                self.update(selected_sf, config)
                continue
            elif config.strategy == "replace":
                self.delete(config.table)
            self.insert(selected_sf, config)

    def ensure_table_exists(self, table: str, schema: Schema):
        engine = self.get_engine()
        if table in inspect(engine).get_table_names():
            return
        self.create_table(schema, table)

    def create_table(self, schema: Schema, table: str):
        table_columns = []
        for col in schema.cols:
            col_name = col.to
            col_type = getattr(db, col.dtype or "String")
            table_columns.append(Column(col_name, col_type))
        _, metadata = self.get_table(table, False, *table_columns, extend_existing=True)
        metadata.create_all(self.get_engine())

    def delete(self, table_name):
        table, _ = self.get_table(table_name, autoload=True)
        self.write_on_db(table.delete())

    def insert(self, selected_sf: SFrame, config: SaveConfig):
        values = selected_sf.to_dict()
        if config.schema:
            columns_map = self._get_columns_map(config.schema)
            values = [
                {columns_map[k]: v for k, v in row.items() if k in columns_map}
                for row in values
            ]

        table, _ = self.get_table(config.table, autoload=True)
        self.write_on_db(table.insert(), values)

    def update(self, selected_sf: SFrame, config: SaveConfig):
        table, _ = self.get_table(config.table, autoload=True)
        values = selected_sf.to_dict()
        id_cols = config.schema.get_id(return_first=False)

        rows_to_update = self._get_existing_rows(table, values, config.schema)
        rows_to_create = []
        self._update_rows_list(rows_to_update, rows_to_create, values, config.schema)

        if rows_to_create:
            self.write_on_db(table.insert(), rows_to_create)
        db_id_cols = tuple(getattr(table.c, id_col.to) for id_col in id_cols)
        for row in rows_to_update:
            condition = None
            for db_id in db_id_cols:
                new_condition = db_id == row.pop(db_id.key)
                if condition is None:
                    condition = new_condition
                else:
                    condition = and_(condition, new_condition)

            update_query = update(table).where(condition).values(row)
            self.write_on_db(update_query)

    def create_index(self, config):
        table, metadata = self.get_table(config.table, autoload=True)
        current_indexes = set()
        for index in table.indexes:
            hashed_cols = self.hash_columns([col.key for col in index.columns])
            current_indexes.add(hashed_cols)

        for index in config.indexes:
            index_cols = [index] if isinstance(index, str) else index
            index_hash = self.hash_columns(index_cols)
            if index_hash in current_indexes:
                continue

            index_name = f"{'_'.join(index_cols)}_index_{table.name}"
            index_obj = Index(
                index_name,
                *[getattr(table.c, index_col) for index_col in index_cols],
            )
            index_obj.create(self.get_engine())
            current_indexes.add(index_hash)

    def _update_rows_list(self, rows_to_update, rows_to_create, values, schema):
        col_to_func_map = {
            col.original: col.update_func or "replace"
            for col in schema.cols
            if not col.is_id
        }
        id_cols = schema.get_id(return_first=False)

        id_to_db_records_map = {
            tuple(row[id_col.to] for id_col in id_cols): row for row in rows_to_update
        }

        for col in schema.cols:
            if col.is_id:
                continue
            func = self.get_func(col_to_func_map[col.original])
            for row in values:
                db_records_key = tuple(row[id_col.original] for id_col in id_cols)
                db_result = id_to_db_records_map.get(db_records_key)
                if db_result is None:
                    id_to_db_records_map[db_records_key] = db_result = {
                        id_col.to: row[id_col.original] for id_col in id_cols
                    }
                    rows_to_create.append(db_result)
                new_value = row[col.original]
                if isinstance(new_value, str) and new_value.isdigit():
                    new_value = float(new_value)
                db_result[col.to] = func((db_result.get(col.to, 0), new_value))

    def _get_existing_rows(self, table, values, schema):
        id_cols = schema.get_id(return_first=False)
        condition_values = {id_col.to: [] for id_col in id_cols}
        for row in values:
            for id_col in id_cols:
                condition_values[id_col.to].append(row[id_col.original])
        condition = true()
        for to, vals in condition_values.items():
            condition = and_(condition, getattr(table.c, to).in_(vals))

        query = select(*[getattr(table.c, col.to) for col in schema.cols]).where(
            condition
        )
        return self.get_from_db(query)

    def get_table(self, table_name, autoload, *args, **kwargs):
        metadata = MetaData()
        if autoload:
            kwargs.setdefault("autoload_with", self.get_engine())
        return Table(table_name, metadata, *args, **kwargs), metadata

    def get_from_db(self, query):
        with self.get_engine().connect() as conn:
            result = conn.execute(query)
            dict_result = []
            for row in result.mappings():
                dict_result.append(dict(row))
            return dict_result

    @staticmethod
    def fill_cols_to_field(schema):
        for col in schema.cols:
            col.to = col.to or col.original

    @staticmethod
    def _get_columns_map(schema: Schema, to_db=True):
        if to_db:
            return {col.original: col.to for col in schema.cols}
        return {col.to: col.original for col in schema.cols}

    @staticmethod
    def get_func(func_name):
        if func_name not in (valid_fns := UpdateFuncs.__args__):
            raise InvalidArgumentsError(
                "function %s is not valid. Choose on these: %s"
                % (func_name, " - ".join(valid_fns))
            )

        if func_name == "sum":
            return sum
        elif func_name == "mean":
            return statistics.mean
        else:
            return lambda vals: vals[1]

    @staticmethod
    def hash_columns(columns: List[str]):
        joined_cols = "-".join(set(columns))
        return hashlib.sha256(joined_cols.encode("utf-8")).hexdigest()
