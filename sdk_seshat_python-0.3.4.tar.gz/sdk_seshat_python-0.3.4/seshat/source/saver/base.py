from dataclasses import dataclass
from typing import List, Literal

from seshat.data_class import SFrame
from seshat.general import configs
from seshat.general.exceptions import InvalidArgumentsError
from seshat.transformer.schema import Schema


@dataclass
class SaveConfig:
    sf_key: str
    table: str
    schema: Schema
    strategy: Literal["insert", "replace", "update"] = "replace"
    indexes: List[List[str] | str] = ()


class Saver:
    def __init__(self, save_configs: List[SaveConfig]):
        # Check for update configs id columns have been specified
        [
            config.schema.get_id()
            for config in save_configs
            if config.strategy == "update"
        ]

        self.save_configs = save_configs

    def __call__(self, sf: SFrame, *args, **kwargs):
        self.save(sf)

    def save(self, sf: SFrame, *args, **kwargs):
        raise NotImplementedError()
