import pandas as pd
from pyspark.sql import DataFrame as PySparkDataFrame
from pyspark.sql import functions as F

from seshat.general import configs


def get_popular_contracts(d: object, limit=100, *args, **kwargs):
    if isinstance(d, pd.DataFrame):
        return _get_popular_contracts_df(d, limit=limit, *args, **kwargs)
    return _get_popular_contracts_spf(d, limit=limit, *args, **kwargs)


def _get_popular_contracts_df(
    df, limit=100, contract_address_col=configs.CONTRACT_ADDRESS_COL, *args, **kwargs
):
    df_agg = df.groupby(contract_address_col).size().reset_index(name="count")
    df_agg = df_agg.sort_values(by="count", ascending=False).reset_index(drop=True)

    popular_contracts = df_agg.head(limit)[contract_address_col]
    return popular_contracts


def _get_popular_contracts_spf(
    spf: PySparkDataFrame,
    limit=100,
    contract_address_col=configs.CONTRACT_ADDRESS_COL,
    *args,
    **kwargs
):
    spf_agg = spf.groupBy(contract_address_col).count()
    spf_agg = spf_agg.orderBy(F.col("count").desc())
    return spf_agg.limit(limit).select(contract_address_col)
