import pandas as pd
from pandas.core.dtypes.common import is_numeric_dtype
from pyspark.sql import DataFrame as PySparkDataFrame
from pyspark.sql.functions import col as sp_col
from pyspark.sql.types import NumericType


def ensure_is_numeric(d: object, col: str):
    if isinstance(d, pd.DataFrame):
        return _ensure_df_is_numeric(d, col)
    return _ensure_spf_is_numeric(d, col)


def _ensure_df_is_numeric(df: pd.DataFrame, col: str):
    if not is_numeric_dtype(df[col]):
        df[col] = pd.to_numeric(df[col], errors="coerce")
    return df


def _ensure_spf_is_numeric(spf: PySparkDataFrame, col: str):
    if not isinstance(spf.schema[col].dataType, NumericType):
        spf = spf.withColumn(col, sp_col(col).cast("double"))
    return spf
